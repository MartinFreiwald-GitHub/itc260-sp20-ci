    <?php //application/views/templates/footer.php ?>
	<em>&copy; 2015-<?=date('Y')?></em>
    </body>
</html>
