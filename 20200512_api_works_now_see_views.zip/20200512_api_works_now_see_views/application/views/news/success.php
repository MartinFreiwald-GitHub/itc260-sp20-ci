<?php 
//application/views/news/success.php

?>

<h1>Success page</h1>

<p>This is would be nice to see a page here from this message</p>
