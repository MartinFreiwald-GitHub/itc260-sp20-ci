<?php //application/views/pages/about.php?>


<h1>Welcome to my home page!</h1>
<p>Any Slugs you find here will be well behaved!</p>
<p>If you find them in the bathroom, please knock before entering!</p>

